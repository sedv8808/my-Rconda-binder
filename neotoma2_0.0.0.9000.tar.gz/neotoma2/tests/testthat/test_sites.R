types <- c('geochronologic','loss-on-ignition','pollen',
           'plant macrofossil','vertebrate fauna','macroinvertebrate',
           'pollen surface sample','insect','ostracode',
           'water chemistry','diatom','ostracode surface sample',
           'diatom surface sample','geochemistry','physical sedimentology',
           'charcoal','testate amoebae','X-ray fluorescence (XRF)',
           'X-ray diffraction (XRD)','Energy dispersive X-ray spectroscopy (EDS/EDX)')
