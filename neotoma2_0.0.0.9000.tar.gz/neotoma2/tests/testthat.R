library(testthat)
library(neotoma2)

test_check("neotoma2")
