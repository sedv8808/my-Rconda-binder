## ----setOpts, include = FALSE-------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(sf)
library(neotoma2)

## ----getSiteBySiteID----------------------------------------------------------
# Search for site by a single numeric ID:
alex <- get_sites(24)
alex

# Search for sites with multiple IDs using c():
multiple_sites <- get_sites(c(24, 47))
multiple_sites

## ----getsitename--------------------------------------------------------------
alex <- get_sites(sitename = "Alexander Lake")
alex

## ----sitewithwildcardname-----------------------------------------------------
alex <- get_sites(sitename = 'Alexander%')

## ----extractElement-----------------------------------------------------------
alex@sites[[1]]@siteid

## ----setsitefunction----------------------------------------------------------
my_site <- set_site(sitename="My Lake", 
                    geography = st_sf(a=3, st_sfc(st_point(1:2))), 
                    description = "my lake", 
                    altitude = 30)
my_site

## ----getdatasetsbyid----------------------------------------------------------
# Getting datasets by ID
my_datasets <- get_datasets(c(5, 10, 15, 20))
my_datasets

## ----getdatasetsbytype--------------------------------------------------------
# Getting datasets by type
my_pollen_datasets <- get_datasets(datasettype = "pollen", limit = 25)
my_pollen_datasets

## ----searchOffset, eval=FALSE-------------------------------------------------
#  run = TRUE
#  offset <- 0
#  
#  while(run) {
#    sites <- get_sites(offset=offset)
#    if(length(sites) == 0) {
#      run = FALSE
#    }
#    if(exists('allSites')) {
#      allSites <- c(allSites, sites)
#    } else {
#      allSites <- sites
#    }
#    offset <- offset + 25
#  }

## ----bounding box-------------------------------------------------------------

brazil <- '{"type": "Polygon", 
            "coordinates": [[
                [-73.125, -9.102],
                [-56.953, -33.138],
                [-36.563, -7.711],
                [-68.203, 13.923],
                [-73.125, -9.102]
              ]]}'

# We can make the geojson a spatial object if we want to use the
# functionality of the `sf` package.
brazil_sf <- geojsonsf::geojson_sf(brazil)

brazil_datasets <- get_datasets(loc = brazil[1])

## ----leafletBrasil------------------------------------------------------------
plotLeaflet(brazil_datasets)

## ----filterBrasil-------------------------------------------------------------
brasil_dates <- neotoma2::filter(brazil_datasets, datasettype == "geochronologic")

# or:

brasil_dates <- brazil_datasets %>% 
  neotoma2::filter(datasettype == "geochronologic")

# With boolean operators:

brasil_space <- brazil_datasets %>% filter(lat > -18 & lat < -16)

## -----------------------------------------------------------------------------
Names_744BH<-c("Bald Hill", "Blake (sutton)", "High (sudbry)", "Holland", "Little Hosmer", "Long (grnsbo)", "Long (shefld)", "Round (shefld)")
new_sites <- c()
for(Number in Names_744BH){
  sites <- get_sites(sitename=Number)
  new_sites <- c(new_sites, sites)}
new_sites

## ----pubsbyid-----------------------------------------------------------------
one <- get_publications(12)
two <- get_publications(c(12,14))

## ----showSinglePub------------------------------------------------------------
two[[2]]

## ----fulltestPubSearch--------------------------------------------------------
michPubs <- get_publications(search="Michigan", limit=2)

## ----nonsenseSearch-----------------------------------------------------------
noise <- get_publications(search="Canada Banada Nanada", limit = 5)

## ----getSecondPub-------------------------------------------------------------
two[[1]]

## ----subsetPubs---------------------------------------------------------------
# Select publications with Neotoma Publication IDs 1 - 10.
pubArray <- get_publications(1:10)
# Select the first five publications:
subPub <- pubArray[[1:5]]
subPub

## ----setNewPub----------------------------------------------------------------
new_pub <- set_publications(articletitle = 'Myrtle Lake: a late- and post-glacial pollen diagram from northern Minnesota',
                           journal = 'Canadian Journal of Botany',
                           volume = 46)

## ----setPubValue--------------------------------------------------------------
new_pub@pages <- '1397-1410'

